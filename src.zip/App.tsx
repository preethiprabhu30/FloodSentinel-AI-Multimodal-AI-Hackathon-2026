import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

type IconName =
  | "activity"
  | "alert"
  | "arrow"
  | "bridge"
  | "building"
  | "check"
  | "chevron"
  | "clock"
  | "download"
  | "hospital"
  | "layers"
  | "map"
  | "menu"
  | "message"
  | "people"
  | "pin"
  | "road"
  | "route"
  | "satellite"
  | "search"
  | "shield"
  | "sparkles"
  | "x";

const iconPaths: Record<IconName, ReactNode> = {
  activity: <><path d="M4 12h3l2-7 4 14 2-7h5" /></>,
  alert: <><path d="M10.3 2.9 1.8 17a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 2.9a2 2 0 0 0-3.4 0Z" /><path d="M12 9v4M12 17h.01" /></>,
  arrow: <><path d="m9 18 6-6-6-6" /></>,
  bridge: <><path d="M3 19V9M21 19V9M3 15h18M6 15a6 6 0 0 1 12 0M2 19h20" /></>,
  building: <><path d="M4 21V3h10v18M14 9h6v12M8 7h2M8 11h2M8 15h2M17 13h1M17 17h1M2 21h20" /></>,
  check: <><path d="m5 12 4 4L19 6" /></>,
  chevron: <><path d="m9 18 6-6-6-6" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  download: <><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14" /></>,
  hospital: <><path d="M4 21V6h16v15M9 3h6v6H9zM9 14h6M12 11v6M2 21h20" /></>,
  layers: <><path d="m12 2 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5M3 17l9 5 9-5" /></>,
  map: <><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6Z" /><path d="M9 3v15M15 6v15" /></>,
  menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
  message: <><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" /><path d="M8 9h8M8 13h5" /></>,
  people: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8" /></>,
  pin: <><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
  road: <><path d="M8 3 5 21M16 3l3 18M12 4v4M12 12v4M12 20v1" /></>,
  route: <><circle cx="5" cy="19" r="2" /><circle cx="19" cy="5" r="2" /><path d="M7 19h3a2 2 0 0 0 2-2V7a2 2 0 0 1 2-2h3" /></>,
  satellite: <><path d="m13 7 4-4 4 4-4 4-4-4ZM3 17l4-4 4 4-4 4-4-4ZM10 14l4-4M6 8a10 10 0 0 0 10 10M3 8a13 13 0 0 0 13 13" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
  shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></>,
  sparkles: <><path d="m12 3-1.2 3.8L7 8l3.8 1.2L12 13l1.2-3.8L17 8l-3.8-1.2L12 3ZM5 15l-.8 2.2L2 18l2.2.8L5 21l.8-2.2L8 18l-2.2-.8L5 15ZM19 13l-.6 1.4L17 15l1.4.6L19 17l.6-1.4L21 15l-1.4-.6L19 13Z" /></>,
  x: <><path d="m6 6 12 12M18 6 6 18" /></>,
};

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {iconPaths[name]}
    </svg>
  );
}

function Button({
  children,
  icon,
  variant = "secondary",
  onClick,
  className = "",
}: {
  children?: ReactNode;
  icon?: IconName;
  variant?: "primary" | "secondary" | "ghost" | "icon";
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button className={`button button--${variant} ${className}`} onClick={onClick}>
      {icon && <Icon name={icon} size={17} />}
      {children}
    </button>
  );
}

const incidents = [
  { name: "Rasuwa sector", detail: "Dhunche–Syabrubesi corridor", status: "Critical", tone: "critical", lat: 28.1608, lng: 85.3698 },
  { name: "Nuwakot sector", detail: "Trishuli river crossing", status: "Severe", tone: "severe", lat: 27.9195, lng: 85.1652 },
  { name: "Dhading sector", detail: "Galchhi access route", status: "Watch", tone: "watch", lat: 27.8159, lng: 84.9367 },
];

const settlements = [
  { name: "Thuman", people: "1,120", reason: "Bridge B-14 lost", eta: "Air only", level: "critical" },
  { name: "Briddim", people: "668", reason: "2 road breaks", eta: "6h detour", level: "critical" },
  { name: "Timure", people: "1,043", reason: "Debris on H03", eta: "4h detour", level: "severe" },
  { name: "Gatlang", people: "941", reason: "Route uncertain", eta: "Verify", level: "watch" },
];

type LiveLocation = {
  latitude: number;
  longitude: number;
  accuracy: number;
  updatedAt: number;
};

type LiveReading = {
  precipitation: number;
  rain: number;
  wind: number;
  weatherCode: number;
  discharge: number | null;
  dischargeMean: number | null;
  dischargeMax: number | null;
  timezone: string;
  updatedAt: string;
};

function MetricCard({ icon, label, value, change, tone }: { icon: IconName; label: string; value: string; change: string; tone: string }) {
  return (
    <div className="metric-card">
      <div className={`metric-icon metric-icon--${tone}`}><Icon name={icon} /></div>
      <div className="metric-copy">
        <span>{label}</span>
        <strong>{value}</strong>
      </div>
      <span className={`metric-change metric-change--${tone}`}>{change}</span>
    </div>
  );
}

function LayerToggle({ label, color, active, onClick }: { label: string; color: string; active: boolean; onClick: () => void }) {
  return (
    <button className={`layer-toggle ${active ? "layer-toggle--active" : ""}`} onClick={onClick}>
      <span className={`layer-dot layer-dot--${color}`} />
      <span>{label}</span>
      <span className="switch"><span /></span>
    </button>
  );
}

export default function App() {
  const [selected, setSelected] = useState(0);
  const [activeTab, setActiveTab] = useState<"overview" | "settlements" | "report">("overview");
  const [layers, setLayers] = useState({ flood: true, roads: true, buildings: false });
  const [notifications, setNotifications] = useState(true);
  const [language, setLanguage] = useState<"EN" | "ने">("EN");
  const [lastSync, setLastSync] = useState(12);
  const [reportReady, setReportReady] = useState(false);
  const [location, setLocation] = useState<LiveLocation | null>(null);
  const [locationPrompt, setLocationPrompt] = useState(true);
  const [locationState, setLocationState] = useState<"idle" | "requesting" | "active" | "error">("idle");
  const [locationError, setLocationError] = useState("");
  const [liveReading, setLiveReading] = useState<LiveReading | null>(null);
  const [liveError, setLiveError] = useState("");
  const watcherRef = useRef<number | null>(null);

  useEffect(() => {
    const timer = window.setInterval(() => setLastSync((value) => (value >= 59 ? 1 : value + 1)), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    return () => {
      if (watcherRef.current !== null) navigator.geolocation.clearWatch(watcherRef.current);
    };
  }, []);

  const requestLiveLocation = useCallback(() => {
    if (!("geolocation" in navigator)) {
      setLocationState("error");
      setLocationError("Location is not supported by this device or browser.");
      return;
    }
    if (watcherRef.current !== null) navigator.geolocation.clearWatch(watcherRef.current);
    setLocationState("requesting");
    setLocationError("");
    watcherRef.current = navigator.geolocation.watchPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          updatedAt: position.timestamp,
        });
        setLocationState("active");
        setLocationPrompt(false);
      },
      (error) => {
        setLocationState("error");
        setLocationError(
          error.code === error.PERMISSION_DENIED
            ? "Location permission was blocked. Enable Location for this site in your phone settings and try again."
            : "Your GPS position could not be acquired. Move outdoors and try again.",
        );
      },
      { enableHighAccuracy: true, maximumAge: 15_000, timeout: 20_000 },
    );
  }, []);

  useEffect(() => {
    if (!location) return;
    const controller = new AbortController();

    async function fetchLiveFeeds() {
      setLiveError("");
      try {
        const latitude = location!.latitude.toFixed(5);
        const longitude = location!.longitude.toFixed(5);
        const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=precipitation,rain,weather_code,wind_speed_10m&timezone=auto`;
        const floodUrl = `https://flood-api.open-meteo.com/v1/flood?latitude=${latitude}&longitude=${longitude}&daily=river_discharge,river_discharge_mean,river_discharge_max&forecast_days=7`;
        const [weatherResponse, floodResponse] = await Promise.all([
          fetch(weatherUrl, { signal: controller.signal }),
          fetch(floodUrl, { signal: controller.signal }),
        ]);
        if (!weatherResponse.ok) throw new Error("Live weather feed unavailable");
        const weather = await weatherResponse.json();
        const flood = floodResponse.ok ? await floodResponse.json() : null;
        setLiveReading({
          precipitation: weather.current?.precipitation ?? 0,
          rain: weather.current?.rain ?? 0,
          wind: weather.current?.wind_speed_10m ?? 0,
          weatherCode: weather.current?.weather_code ?? 0,
          discharge: flood?.daily?.river_discharge?.[0] ?? null,
          dischargeMean: flood?.daily?.river_discharge_mean?.[0] ?? null,
          dischargeMax: flood?.daily?.river_discharge_max?.[0] ?? null,
          timezone: weather.timezone_abbreviation ?? weather.timezone ?? "Local",
          updatedAt: weather.current?.time ?? new Date().toISOString(),
        });
      } catch (error) {
        if ((error as Error).name !== "AbortError") setLiveError("Live feeds could not be reached. GPS tracking is still active.");
      }
    }

    fetchLiveFeeds();
    const refresh = window.setInterval(fetchLiveFeeds, 5 * 60 * 1000);
    return () => {
      controller.abort();
      window.clearInterval(refresh);
    };
  }, [location?.latitude, location?.longitude]);

  const incident = incidents[selected];
  const mapUrl = useMemo(
    () => {
      const latitude = location?.latitude ?? incident.lat;
      const longitude = location?.longitude ?? incident.lng;
      return `https://maps.google.com/maps?q=${latitude},${longitude}&z=${location ? 15 : 11}&output=embed`;
    },
    [incident, location],
  );

  const risk = useMemo(() => {
    if (!liveReading) return { label: "Waiting for feed", score: "—" };
    const ratio = liveReading.discharge && liveReading.dischargeMean ? liveReading.discharge / liveReading.dischargeMean : 0;
    if (liveReading.precipitation >= 7.5 || ratio >= 2) return { label: "High flood signal", score: "HIGH" };
    if (liveReading.precipitation >= 2.5 || ratio >= 1.35) return { label: "Elevated signal", score: "WATCH" };
    return { label: "No immediate signal", score: "LOW" };
  }, [liveReading]);

  const toggleLayer = (key: keyof typeof layers) => setLayers((current) => ({ ...current, [key]: !current[key] }));

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><Icon name="satellite" size={22} /></div>
          <div>
            <div className="brand-name">VYOM<span>SETU</span></div>
            <div className="brand-subtitle">SPACE-BASED DISASTER INTELLIGENCE</div>
          </div>
        </div>

        <div className="event-chip">
          <span className="live-pulse" />
            <div><strong>{location ? "LIVE LOCATION ACTIVE" : "LOCATION REQUIRED"}</strong><span>{location ? `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}` : "Tap Use my location to begin"}</span></div>
        </div>

        <div className="top-actions">
          <button className="language-toggle" onClick={() => setLanguage(language === "EN" ? "ने" : "EN")}>
            <span className={language === "EN" ? "active" : ""}>EN</span>
            <span className={language === "ने" ? "active" : ""}>ने</span>
          </button>
          <Button variant="icon" icon="alert" onClick={() => setNotifications(!notifications)} />
          <div className="operator"><span>NR</span><div><strong>NDRRMA Ops</strong><small>Response lead</small></div></div>
        </div>
      </header>

      <aside className="sidebar">
        <nav className="nav-stack" aria-label="Primary navigation">
          <button className="nav-item nav-item--active"><Icon name="map" /><span>Live map</span></button>
          <button className="nav-item"><Icon name="activity" /><span>Analysis</span></button>
          <button className="nav-item"><Icon name="route" /><span>Routes</span></button>
          <button className="nav-item"><Icon name="message" /><span>Reports</span></button>
        </nav>
        <div className="sidebar-bottom">
          <div className="system-health"><span className="health-ring"><span /></span><div><strong>All systems online</strong><small>3 sources connected</small></div></div>
          <div className="prototype-note"><Icon name="shield" size={16} /><span>GPS and public feeds are live. Satellite damage classification still requires field verification.</span></div>
        </div>
      </aside>

      <section className="workspace">
        <div className="page-heading">
          <div>
            <div className="eyebrow"><span>TRACK B</span> MAPPING FLOOD DAMAGE FROM SPACE</div>
            <h1>Trishuli corridor overview</h1>
            <p>Satellite-derived impact intelligence for coordinated rescue operations.</p>
          </div>
          <div className="heading-actions">
            <Button icon="pin" onClick={() => setLocationPrompt(true)}>{location ? "GPS active" : "Use my location"}</Button>
            <Button icon="download">Export SITREP</Button>
            <Button icon="sparkles" variant="primary" onClick={() => { setReportReady(true); setActiveTab("report"); }}>Generate AI report</Button>
          </div>
        </div>

        <div className={`notice-bar ${location ? "notice-bar--live" : ""}`}>
          <Icon name={location ? "pin" : "alert"} size={17} />
          <span><strong>{location ? "Live phone mode" : "Location needed"}</strong> · {location ? `GPS ±${Math.round(location.accuracy)} m · Weather refreshes every 5 minutes.` : "Allow precise location to load real readings for your current position."}</span>
          <button onClick={() => setLocationPrompt(true)}>{location ? "Location details" : "Enable now"} <Icon name="chevron" size={15} /></button>
        </div>

        <div className="metrics-grid">
          {location ? <>
            <MetricCard icon="activity" label="Current precipitation" value={liveReading ? `${liveReading.precipitation.toFixed(1)} mm` : "Loading"} change={liveReading ? `${liveReading.timezone} feed` : "Connecting"} tone="blue" />
            <MetricCard icon="route" label="River discharge" value={liveReading?.discharge !== null && liveReading?.discharge !== undefined ? `${liveReading.discharge.toFixed(1)} m³/s` : "Unavailable"} change="GloFAS model" tone="orange" />
            <MetricCard icon="alert" label="Flood signal" value={risk.score} change={risk.label} tone="red" />
            <MetricCard icon="pin" label="GPS accuracy" value={`±${Math.round(location.accuracy)} m`} change="Live device GPS" tone="purple" />
          </> : <>
            <MetricCard icon="pin" label="Phone location" value="Required" change="Tap to enable" tone="blue" />
            <MetricCard icon="activity" label="Live weather" value="Waiting" change="Open-Meteo" tone="orange" />
            <MetricCard icon="route" label="River discharge" value="Waiting" change="GloFAS model" tone="red" />
            <MetricCard icon="shield" label="Risk signal" value="Waiting" change="Needs location" tone="purple" />
          </>}
        </div>

        <div className="dashboard-grid">
          <section className="map-card">
            <div className="map-toolbar">
              <div className="search-box"><Icon name="search" /><input aria-label="Search map" placeholder="Search settlement, road or coordinates" /></div>
              <div className="map-date"><Icon name="clock" /><span>Post-event</span><strong>02 Sep 2026</strong></div>
            </div>

            <div className="map-area">
              <iframe title="Google Maps view of selected analysis sector" src={mapUrl} loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
              <div className="map-tint" />
              {!location && layers.flood && <div className="flood-zone flood-zone--one" />}
              {!location && layers.flood && <div className="flood-zone flood-zone--two" />}
              {!location && <div className="map-route map-route--one" />}
              {!location && <div className="map-route map-route--two" />}
              {!location && <div className="map-marker map-marker--critical"><span><Icon name="alert" size={16} /></span><div><strong>BRIDGE B-14</strong><small>Scenario output · 91%</small></div></div>}
              {!location && <div className="map-marker map-marker--isolated"><span><Icon name="people" size={16} /></span><div><strong>THUMAN</strong><small>Scenario analysis only</small></div></div>}
              {!location && <div className="map-marker map-marker--hospital"><span><Icon name="hospital" size={16} /></span></div>}
              {location && <div className="live-location-marker"><span /><i /></div>}
              {location && <div className="live-data-card"><span>LIVE AT YOUR LOCATION</span><strong>{risk.label}</strong><small>{liveReading ? `Rain ${liveReading.precipitation.toFixed(1)} mm · Wind ${liveReading.wind.toFixed(0)} km/h` : "Connecting to live environmental feeds…"}</small>{liveError && <small className="feed-error">{liveError}</small>}</div>}

              <div className="layer-panel">
                <div className="panel-title"><Icon name="layers" size={16} /> Map layers</div>
                <LayerToggle label="Flood & debris" color="blue" active={layers.flood} onClick={() => toggleLayer("flood")} />
                <LayerToggle label="Road status" color="red" active={layers.roads} onClick={() => toggleLayer("roads")} />
                <LayerToggle label="Exposed buildings" color="orange" active={layers.buildings} onClick={() => toggleLayer("buildings")} />
              </div>

              {!location && <div className="map-legend">
                <span><i className="legend-flood" /> Scenario flood probability</span>
                <span><i className="legend-route" /> Scenario route break</span>
              </div>}
              <div className="google-label">Map context © Google</div>
            </div>
          </section>

          <aside className="insight-panel">
            <div className="panel-tabs">
              <button className={activeTab === "overview" ? "active" : ""} onClick={() => setActiveTab("overview")}>Overview</button>
              <button className={activeTab === "settlements" ? "active" : ""} onClick={() => setActiveTab("settlements")}>Cut off <span>4</span></button>
              <button className={activeTab === "report" ? "active" : ""} onClick={() => setActiveTab("report")}>SITREP</button>
            </div>

            {activeTab === "overview" && (
              <div className="panel-content">
                <div className="section-heading"><div><span>SECTOR RISK</span><h2>Priority areas</h2></div><small>Updated {lastSync}s ago</small></div>
                <div className="incident-list">
                  {incidents.map((item, index) => (
                    <button key={item.name} className={`incident-row ${selected === index ? "incident-row--active" : ""}`} onClick={() => setSelected(index)}>
                      <span className={`risk-bar risk-bar--${item.tone}`} />
                      <span className="incident-copy"><strong>{item.name}</strong><small>{item.detail}</small></span>
                      <span className={`status status--${item.tone}`}>{item.status}</span>
                      <Icon name="chevron" size={16} />
                    </button>
                  ))}
                </div>

                <div className="model-card">
                  <div className="model-card-head"><div className="model-icon"><Icon name="sparkles" /></div><div><span>AI FLOOD SEGMENTATION</span><strong>Model confidence</strong></div><b>87%</b></div>
                  <div className="confidence-track"><span /></div>
                  <div className="model-stats"><span><small>SAR change</small><strong>High</strong></span><span><small>Optical cloud</small><strong>38%</strong></span><span><small>Agreement</small><strong>0.82 IoU</strong></span></div>
                </div>

                <div className="source-card">
                  <div className="source-heading"><span>DATA PIPELINE</span><small><i /> Live-style demo</small></div>
                  <div className="source-row"><Icon name="satellite" /><div><strong>Sentinel-1 SAR</strong><small>Descending orbit · VV/VH</small></div><span>READY</span></div>
                  <div className="source-row"><Icon name="map" /><div><strong>Sentinel-2 L2A</strong><small>Optical confirmation</small></div><span>READY</span></div>
                  <div className="source-row"><Icon name="route" /><div><strong>OpenStreetMap</strong><small>Pre-event network snapshot</small></div><span>READY</span></div>
                </div>
              </div>
            )}

            {activeTab === "settlements" && (
              <div className="panel-content">
                <div className="section-heading"><div><span>NETWORK ANALYSIS</span><h2>Potentially isolated</h2></div><small>3,772 people</small></div>
                <p className="section-intro">Routes are tested to the nearest reachable hospital after removing likely damaged segments.</p>
                <div className="settlement-list">
                  {settlements.map((place, index) => (
                    <div className="settlement-row" key={place.name}>
                      <div className={`settlement-rank settlement-rank--${place.level}`}>{index + 1}</div>
                      <div><strong>{place.name}</strong><small>{place.people} people · {place.reason}</small></div>
                      <span>{place.eta}</span>
                    </div>
                  ))}
                </div>
                <Button variant="primary" icon="route" className="full-button">Open rescue route planner</Button>
              </div>
            )}

            {activeTab === "report" && (
              <div className="panel-content">
                <div className="section-heading"><div><span>BILINGUAL COPILOT</span><h2>Situation report</h2></div><small>Draft</small></div>
                {reportReady ? (
                  <div className="report-card">
                    <div className="report-meta"><span>Generated from 7 mapped indicators</span><span className="verified"><Icon name="check" size={13} /> Grounded</span></div>
                    <h3>Operational summary · 08:40 NPT</h3>
                    <p>Analysis indicates <strong>38.4 km²</strong> of possible flood or debris impact across the selected corridor. Four settlements with an estimated population of <strong>3,772</strong> may lack a passable road route to hospital care.</p>
                    <p>Highest priority is Thuman, where Bridge B-14 is classified as likely destroyed with 91% model confidence. Air reconnaissance is recommended before routing field teams.</p>
                    <div className="report-warning"><Icon name="alert" size={15} /><span>Satellite evidence is not field confirmation. Clouds, radar shadow and stale road data may cause errors.</span></div>
                    <Button icon="download" className="full-button">Download one-page PDF</Button>
                  </div>
                ) : (
                  <div className="empty-report"><div><Icon name="message" size={28} /></div><h3>Create a grounded SITREP</h3><p>Every generated number is locked to current map outputs. No free-form casualty estimates.</p><Button variant="primary" icon="sparkles" onClick={() => setReportReady(true)}>Generate report</Button></div>
                )}
              </div>
            )}
          </aside>
        </div>
      </section>

      {notifications && (
        <div className="notification-toast">
          <div className="toast-icon"><Icon name="alert" /></div>
          <div><span>NEW PRIORITY ALERT</span><strong>Possible road break detected</strong><p>H03 near Timure · Sentinel-1 change signal</p></div>
          <button onClick={() => setNotifications(false)} aria-label="Dismiss notification"><Icon name="x" size={16} /></button>
        </div>
      )}

      {locationPrompt && (
        <div className="location-backdrop" role="presentation">
          <section className="location-dialog" role="dialog" aria-modal="true" aria-labelledby="location-title">
            <div className="location-orbit"><span><Icon name="pin" size={24} /></span></div>
            <span className="dialog-eyebrow">LIVE PHONE MODEL</span>
            <h2 id="location-title">Use your current location</h2>
            <p>VyomSetu needs your phone’s precise GPS position to center Google Maps and request live rainfall and river-discharge data for your coordinates.</p>
            <div className="permission-list">
              <span><Icon name="pin" /><div><strong>Precise GPS</strong><small>Continuously updates while this screen is open</small></div></span>
              <span><Icon name="activity" /><div><strong>Live environmental feeds</strong><small>Open-Meteo weather and GloFAS river discharge</small></div></span>
              <span><Icon name="shield" /><div><strong>Privacy</strong><small>Your coordinates stay in this browser and are not stored</small></div></span>
            </div>
            {locationError && <div className="location-error"><Icon name="alert" size={15} />{locationError}</div>}
            <Button variant="primary" icon="pin" className="full-button location-allow" onClick={requestLiveLocation}>
              {locationState === "requesting" ? "Waiting for phone GPS…" : location ? "Refresh precise location" : "Allow location and start"}
            </Button>
            <button className="location-skip" onClick={() => setLocationPrompt(false)}>Continue with challenge scenario</button>
          </section>
        </div>
      )}

      <nav className="mobile-nav" aria-label="Mobile navigation">
        <button className="active"><Icon name="map" /><span>Map</span></button>
        <button><Icon name="activity" /><span>Analysis</span></button>
        <button onClick={() => setActiveTab("settlements")}><Icon name="route" /><span>Routes</span></button>
        <button onClick={() => setActiveTab("report")}><Icon name="message" /><span>Report</span></button>
      </nav>
    </main>
  );
}
